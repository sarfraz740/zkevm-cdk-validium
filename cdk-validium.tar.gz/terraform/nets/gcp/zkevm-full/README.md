# Setup zkEVM Infrastructure

## Setup

### Prerequisites

- [gcloud CLI](https://cloud.google.com/sdk/docs/install)
- [Terraform](https://developer.hashicorp.com/terraform/downloads)
- A domain name (if using Bridge UI)

### Create GCP Folder

Create GCP Project under Team Folder

In GCP UI, enable the following services:
- Compute Engine
- Secret Manager
- Service Networking API
- Cloud DNS API

Make sure to select the project you are using and click the "Enable" button.

### Setup CLI Permissions

```
gcloud auth login
gcloud auth application-default login
```

### Set gcloud project

```
$ gcloud config set project <gcloud-project-ID>
```

### Copy this directory and modify the settings to your needs

```
$ cp -r ../zkevm-full ../<name of your devnet>
```

### Update Terraform Local Variables

In `main.tf`, update the variables:
```
locals {
  ...
  project_id = "<gcloud-project-id>" # Update this
  ...
  owner           = "ihanafi"  # Update this
  deployment_name = "devnet09" # Update this to your devnet name
  ...
  ssh_pub_keys = ["<ssh user>:${file("path-to-ssh-public-key")}"] # Update this, Ansible will SSH using the <ssh user> and the corresonding private key to the GCP hosts.
}
```

### Create and Update Terraform Backend Storage

This stores the state as an object on GCS. The bucket must exist prior to
configuring the backend.

In GCP, create the bucket under the newly created project and then update `main.tf` with the bucket name:

```
terraform {
  ...
  backend "gcs" {
    bucket = "newly_created_bucket_name" # update this
    ...
  }
  ...
}
```

### (For Bridge UI) Setup Cloudflare

The reason we need a domain with SSL for Bridge UI is because metamask requires the rootchain RPC endpoint be secured with HTTPS. [Source](https://github.com/MetaMask/metamask-extension/issues/14416#issuecomment-1163646989)

For this to work, you must own a cloudflare account and a domain name.

### Initialize Terraform

```
$ terraform init
```

### Create Infrastructure

```
$ terraform apply
```

Or if you have variables that needs to be passed, you can create a `tf.tfvars`
file:

```
datadog_app_key             = "YOUR_DATADOG_APP_KEY"
datadog_api_key             = "YOUR_DATADOG_API_KEY"
zkevm_db_master_password    = "YOUR_SUPER_SECRET_ZKEVM_DB_MASTER_PASS"
explorer_db_master_password = "YOUR_SUPER_SECRET_EXPLORER_DB_MASTER_PASS"
cloudflare_zone_id          = "CLOUD_FLARE_ZONE_ID"
cloudflare_api_token        = "CLOUD_FLARE_API_TOKEN"
```

Then reference the variables like:
```
$ terraform apply -var-file "tf.tfvars"
```

NOTE: If this errors with the following:
```
Plan: 196 to add, 0 to change, 0 to destroy.
╷
│ Error: Invalid index
│
│   on ../../../modules/gcp/zkevm-full/monitors.tf line 18, in locals:
│   18:   percent_25_memory = floor(0.25 * jsondecode(data.http.gcp_machine_types.response_body)["memoryMb"] * 1024)
│     ├────────────────
│     │ data.http.gcp_machine_types.response_body is "{\n  \"error\": {\n    \"code\": 404,\n    \"message\": \"The resource 'projects/zkevm-full-09' was not found\",\n    \"errors\": [\n      {\n        \"message\": \"The resource 'projects/zkevm-full-09' was not found\",\n        \"domain\": \"global\",\n        \"reason\": \"notFound\"\n      }\n    ],\n    \"status\": \"NOT_FOUND\"\n  }\n}\n"
│
│ The given key does not identify an element in this collection value.
╵
```

Just comment out everything in that file and then rerun the `terraform apply`.
