# CDK Validium Setup

1. Begin with the Terraform setup, as described under `terraform/nets/gcp/zkevm-full/README.md`
2. Run CDK Validium automations, as described under `ansible/zkevm/README.md`
