#!/bin/bash

# cat siege.out.log | jq -r '. | to_entries | map_values(.key) | @tsv' | head -n 1
# cat siege.out.log | jq -r '. | to_entries | map_values(.value) | @tsv'

# 1 Pure HTTP
# 1.1 eth_chainID
# 1.2 web3_clientVersion
# 1.3 net_version

# 2 Only Node State DB
# 2.1 eth_blockNumber
# 2.2 eth_getBlockByNumber
# 2.3 eth_syncing
# 2.4 eth_gasPrice

# 3 RPC Memory
# 3.1 eth_newFilter
# 3.2 eth_newBlockFilter
# 3.3 eth_uninstallFilter (NOT IMPLEMENTED)

# 4 MT Call
# 4.1 eth_getBalance
# 4.2 eth_getCode
# 4.3 eth_getStorageAt

# 5 Executor call
# 5.1 eth_call
# 5.2 eth_estimateGas
# 5.3 eth_sendRawTransaction (IMPLEMENTED WITH POLYCLI)


# readonly url=http://rootchain-int-rpc.devnet04.zkevm.polygon.private:8545
readonly url=http://rpc-001:8123

function handle_sigint() {
    echo "Exiting..."
    exit 1
}

main() {
    trap handle_sigint SIGINT

    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/1.1.json" | jq '. + {method: "eth_chainId"}' | tee -a siege.out.log
    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/1.2.json" | jq '. + {method: "web3_clientVersion"}' | tee -a siege.out.log
    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/1.3.json" | jq '. + {method: "net_version"}' | tee -a siege.out.log

    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/2.1.json" | jq '. + {method: "eth_blockNumber"}' | tee -a siege.out.log
    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/2.2.json" | jq '. + {method: "eth_getBlockByNumber"}' | tee -a siege.out.log
    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/2.3.json" | jq '. + {method: "eth_syncing"}' | tee -a siege.out.log
    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/2.4.json" | jq '. + {method: "eth_gasPrice"}' | tee -a siege.out.log

    # siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/3.1.json" | jq '. + {method: "eth_newFilter"}'
    # siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/3.2.json" | jq '. + {method: "eth_newBlockFilter"}'

    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/4.1.json" | jq '. + {method: "eth_getBalance"}' | tee -a siege.out.log
    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/4.2.json" | jq '. + {method: "eth_getCode"}' | tee -a siege.out.log
    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/4.3.json" | jq '. + {method: "eth_getStorageAt"}' | tee -a siege.out.log

    # Call depositCount in the bridge contract
    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/5.1.json" | jq '. + {method: "eth_call"}' | tee -a siege.out.log
    # Estimate gas for updateGlobalExitRoot
    siege --concurrent $1 --reps $2 --benchmark --content-type "application/json" -v "$url POST < bodies/5.2.json" | jq '. + {method: "eth_estimateGas"}' | tee -a siege.out.log
}

main 1 1000

main 2 1000

main 4 1000

main 8 1000

main 16 1000

main 32 1000

main 64 1000

main 128 1000


