### Ansible Prereqs

```
# install the required ansible-galaxy roles and collections
ansible-galaxy install -r requirements.yml
```

### GCP Setup
```bash
gcloud auth login
gcloud auth application-default login # For 
gcloud compute config-ssh --project <gcp_project_id>
gcloud config set project <gcp_project_id>

# For GCP faster ssh connections:
$(gcloud info --format="value(basic.python_location)") -m pip install numpy
```

Generate the Static Inventory for GCP:
```
gcloud compute instances list --filter="labels.deploymentname:{deployment name}" --filter="labels.network:zkevm" --format=json > gcp-inv.json
jq -f inventory/gcp-inventory-filter.jq gcp-inv.json > inventory/gcp-static.json

# check the inventory
ansible-inventory --graph
ansible-inventory --list
```

Make sure to update `ansible.cfg` inventory default to:
```
[defaults]
# GCP inventory
inventory = inventory/gcp-static.json
```

and if you are not using Ansible vaults, delete the following line in `ansible.cfg`:
```
[defaults]
...
vault_password_file = password.txt
```

### AWS Setup
```bash
aws configure sso
```

Make sure to update `ansible.cfg` inventory default to:
```
[defaults]
inventory = inventory/aws_ec2.yml
```

### Update required vars

Under `group_vars/all.yml`, update the variables to reflect your new devnet:
```
...
clean_deploy_title: devnet08 # Update this, usually to the deployment_name in terraform
...
ansible_ssh_private_key_file: ~/cert/2022-07-05-devnets-generic.key # Update this to the corresponding private key of your ssh_pub_keys that you put in terraform.
...
cloudflare_domain: hardfork.dev # Update this to your domain name on cloudflare
...
zkevm_keystore_password: "super_secret_password" # Update this
datadog_postgres_password: "super_secret_password" # Update this
...
zkevm_db_password: "super_secret_password" # Update this to the value of zkevm_db_master_password from terraform
blockscout_db_password: "super_secret_password" # Update this to the value of explorer_db_master_password from terraform
blockscout_db_key_base: "super_secret_password" # Update this
...
datadog_api_token: "super_secret_password" # Update this to the value of datadog_api_key from terraform
...
zkevm_prover_db_password: "super_secret_password" # Update this
zkevm_state_db_password: "super_secret_password" # Update this
zkevm_pool_db_password: "super_secret_password" # Update this
zkevm_bridge_db_password: "super_secret_password" # Update this
zkevm_committee_db_password: "super_secret_password" # Update this
...
```

### Run Ansible Playbook
```
# Run the whole playbook
ansible-playbook --ask-become-pass site.yml

# Or you can run a playbook by tags
ansible-playbook --tags prover site.yml
ansible-playbook --tags zknode site.yml
ansible-playbook --tags bridge site.yml
ansible-playbook --tags dataavailability site.yml
```

### Important Final Step: Bridge and Funding Necessary Accounts

When it comes to bridging, there is a specific process that must be followed on
the first bridge. This process primarily ensures that the `claimtxmanager` account is
funded allowing further bridges.

1. Using any L1 prefunded account, bridge over any amount > 100000 ether.
2. In L2, transfer the funds from that newly funded account to the `claimtxmanager` account as specified under `zkevm_l2_claimtxmanager_address` in the Ansible vars.

For example:
```
cast send --legacy --private-key <funded l2 account private key> --rpc-url <L2 RPC> --value 100000ether <zkevm_l2_claimtxmanager_address>
```

Once this is done, to simulate more of a productional environment where gas prices are set, change the following in the `roles/zk-node/templates/config.toml`:
```
...
[L2GasPriceSuggester]
Type = "default"
UpdatePeriod = "10s"
Factor = 0.1
# NOTE: Change DefaultGasPriceWei back from 0 to 1000000000 after funding claimtxmanager
DefaultGasPriceWei = 1000000000
...

# also make sure the Pool allows 0 gas price
[Pool]
...
DefaultMinGasPriceAllowed = 0
...
```

Then redeploy zknode:
```
ansible-playbook --ask-become-pass --tags zknode site.yml
```

> Eventually, this will be converted into a step in our Ansible playbooks if this officially
becomes the final process.

### Helpful Scripts
```bash
# check the inventory
ansible-inventory --graph
ansible-inventory --list

# confirm we can ping everything
ansible all -m ping

ansible-playbook --ask-become-pass site.yml

ansible-playbook --tags prover site.yml
ansible-playbook --tags zknode site.yml
ansible-playbook --tags bridge site.yml

ansible-playbook --tags geth --limit rootchain site.yml
ansible-playbook --tags dataavailability --limit dataavailability site.yml

ansible ethtxmanager:l2gaspricer:sequencesender:rpc:sequencer:synchronizer:aggregator -m shell -b -a 'systemctl restart zk-node'
ansible prover:executor:hashdb -m shell -b -a 'systemctl status zk-prover'
ansible explorer -m shell -b -a 'systemctl status explorer'

ansible dataavailability -m shell -b -a 'systemctl stop dataavailability'
ansible-playbook --tags dataavailability --limit dataavailability site.yml
ansible-playbook -e partial_run=true -e partial_run_host=dataavailability-001 --tags dataavailability --limit dataavailability site.yml

cat local-extra-vars.yml | grep zkevm_db_password -A 7 | tail -n+2 | sed 's/^ *//' | ansible-vault decrypt --vault-password-file password.txt; echo
cat local-extra-vars.yml | grep blockscout_db_password -A 7 | tail -n+2 | sed 's/^ *//' | ansible-vault decrypt --vault-password-file password.txt; echo

ansible all -m shell -b -a 'truncate -s 0 /var/log/syslog*'
ansible sequencesender -m shell -b -a 'truncate -s 0 /var/log/syslog*'

ansible rpc -m shell -b -a 'echo "#!/bin/bash\ntruncate -s 0 /var/log/syslog*\n" > /etc/cron.hourly/syslog-truncate.sh; chmod a+x /etc/cron.hourly/syslog-truncate.sh'

ansible sequencer_001 -m debug -a var=zkevm_db_password

```

```bash
# Open a tab to each server
ansible-inventory --list | \
    jq -r '. | del(._meta, .all, .aws_ec2) |
        to_entries[] |
        select((.value.hosts | length) == 1) |
        "--tab --command \"ssh ubuntu@" +
            .value.hosts[0] +
            "\" --initial-title=\"" + .key + "\"" +
            " --dynamic-title-mode=none" +
            " --execute \"sudo atop\" \\"' |
    grep "_"

# try to tail the various logs
sudo journalctl -f -u zk-node.service
sudo journalctl -f -u zkevm-bridge.service
sudo journalctl -f -u dataavailability.service
sudo journalctl -f -u zk-prover.service
sudo journalctl -f -u geth.service
sudo journalctl -f -u explorer.service
```


### Links

Assumming everything runs as expected, we'll probably have the following addresses:

L2 Explorer: https://explorer.hardfork.dev/
Bridge: https://bridge.hardfork.dev/
L2 RPC: https://rpc.hardfork.dev/
L1 RPC: https://rootchain.hardfork.dev/
Dashboard: https://app.datadoghq.com/dashboard/qi4-5jf-im8/zkevm-devnet-dashboard
Funded Addresses: https://docs.google.com/spreadsheets/d/1HCKfpEN_9DTz68fjg5vw3OHOKBd5k-lRDpuXPvOoVtk/edit?usp=sharing

```bash
polycli wallet inspect \
        --addresses 50 \
        --mnemonic 'code code code code code code code code code code code quality' | \
    jq -r '.Addresses[].ETHAddress' | \
    xargs -i cast balance \
          --rpc-url https://rpc.hardfork.dev {}
```

### Quick Reset


```bash
ansible-playbook full-reset.yml
ansible-playbook --tags geth,prover,zknode,dataavailability,bridge,explorer site.yml
```

Optional commands if we want to reset the prover binary and have it get rebuilt:

```bash
ansible hashdb:prover:executor -m shell -b -a 'rm /var/lib/zkevm-prover/build/zkProver'
```

### GDB for extra debugging power

Modify the `makefile` to use `-g`

```diff
diff --git a/Makefile b/Makefile
index a3b49f9f..91f27fc3 100644
--- a/Makefile
+++ b/Makefile
@@ -14,7 +14,7 @@ endif

 CXX := g++
 AS := nasm
-CXXFLAGS := -std=c++17 -Wall -pthread -flarge-source-files -Wno-unused-label -rdynamic -mavx2 #-Wfatal-errors
+CXXFLAGS := -std=c++17 -g -Wall -pthread -flarge-source-files -Wno-unused-label -rdynamic -mavx2 #-Wfatal-errors
 LDFLAGS := -lprotobuf -lsodium -lgrpc -lgrpc++ -lgrpc++_reflection -lgpr -lpthread -lpqxx -lpq -lgmp -lstdc++ -lomp -lgmpxx -lsecp256k1 -lcrypto -luuid -L$(LIBOMP)
 CFLAGS := -fopenmp
 ASFLAGS := -felf64
```
```bash
gdb --args ./build/zkProver -c /etc/zkevm/config.json
```

```text
Rough steps to debug:

list 482
info sources
break 482
run
step - to step into
next - to step over
```
