#!/bin/bash

main() {
    # aria2c -x6 -s6 https://de012a78750e59b808d922b39535e862.s3.eu-west-1.amazonaws.com/{{ zkevm_prover_config_version }}.tgz
    aria2c -x6 -s6 http://de012a78750e59b808d922b39535e862.s3-website-eu-west-1.amazonaws.com/{{ zkevm_prover_config_version }}.tgz

    tar xzf {{ zkevm_prover_config_version }}.tgz

    touch /etc/zkevm/.prover-files-downloaded

    systemctl start zk-prover
}

main;
