CREATE USER datadog with password '{{ datadog_postgres_password }}';

-- Grant rootuser perms (GCP root user isn't the same as superuser)
GRANT datadog TO {{ zkevm_database_root_user }};
