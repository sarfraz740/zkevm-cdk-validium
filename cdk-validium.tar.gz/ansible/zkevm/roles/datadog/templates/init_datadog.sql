
CREATE USER datadog WITH password '{{ datadog_postgres_integration_password }}';
CREATE EXTENSION pg_stat_statements;

