#!/bin/bash
polycli nodekey --ip $(hostname -I | head -n 1) > /etc/geth/nodekey.json
hostname | awk -F. '{print $1}' | sed 's/.*-0*//' > /etc/geth/host.index
polycli wallet inspect --addresses 20 --mnemonic "{{ zkevm_contract_deployer_mnemonic }}" | jq -r '.Addresses['$(cat /etc/geth/host.index)'-1]' > /etc/geth/polykey.json
cat /etc/geth/polykey.json | jq -r '.HexPrivateKey' | tr -d "\n" > /etc/geth/privkey
head -c 32 < /dev/urandom | polycli hash keccak256 | tr -d "\n" > /etc/geth/password
geth init --datadir /var/lib/geth /etc/geth/genesis.json
geth account import --password /etc/geth/password --keystore /var/lib/geth/keystore /etc/geth/privkey
cat /etc/geth/nodekey.json  | jq -r '.PrivateKey' | tr -d "\n" > /var/lib/geth/geth/nodekey
chown -R geth:geth-group /etc/geth
chown -R geth:geth-group /var/lib/geth
