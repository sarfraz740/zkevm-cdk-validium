# zkEVM DB Schema
> Warning: Do NOT edit manually. This file is auto-generated via `gen-doc.sh`
## committee_db Schema
![committee_db Schema](schema/committee_db/schema.svg)
> More details of committee_db can be found [here](schema/committee_db/README.md)
## prover_db Schema
![prover_db Schema](schema/prover_db/schema.svg)
> More details of prover_db can be found [here](schema/prover_db/README.md)
## state_db Schema
![state_db Schema](schema/state_db/schema.svg)
> More details of state_db can be found [here](schema/state_db/README.md)
## pool_db Schema
![pool_db Schema](schema/pool_db/schema.svg)
> More details of pool_db can be found [here](schema/pool_db/README.md)
## bridge_db Schema
![bridge_db Schema](schema/bridge_db/schema.svg)
> More details of bridge_db can be found [here](schema/bridge_db/README.md)
