#!/bin/bash
db=$(psql -d zkevm -h $ZKEVM_DBMON_DATABASE_HOST -p 5432 --username=$ZKEVM_DBMON_DATABASE_USER -c 'select datname from pg_catalog.pg_database' | grep -v -e "zkevm" -e "datname" -e "----" -e "template0" -e "rdsadmin" -e "template1" -e "postgres" -e "(.*" -e "^$" | awk '{$1=$1};1')

db_list=($db) # split into list

echo "# zkEVM DB Schema" > temp_docs.md
echo "> Warning: Do NOT edit manually. This file is auto-generated via \`gen-doc.sh\`" >> temp_docs.md
for db_name in "${db_list[@]}"; do
  echo "Generating $db_name docs..."
  tbls doc postgres://$ZKEVM_DBMON_DATABASE_USER:$ZKEVM_DBMON_DATABASE_PASS@$ZKEVM_DBMON_DATABASE_HOST:5432/$db_name schema/$db_name --exclude "public.*" --force
  echo "## $db_name Schema" >> temp_docs.md
  echo "![$db_name Schema](schema/$db_name/schema.svg)" >> temp_docs.md
  echo "> More details of $db_name can be found [here](schema/$db_name/README.md)" >> temp_docs.md
done

mv temp_docs.md README.md
rm -rf temp_docs.md
