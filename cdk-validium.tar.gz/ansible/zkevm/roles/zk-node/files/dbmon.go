package main

import (
	"database/sql"
	"fmt"
	_ "github.com/lib/pq"
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"net/http"
	"os"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

const (
	POOL_DB   string = "pool_db"
	STATE_DB  string = "state_db"
	PROVER_DB string = "prover_db"
	BRIDGE_DB string = "bridge_db"
)

type MetricTypes string

const (
	GAUGE   MetricTypes = "gauge"
	COUNTER MetricTypes = "counter"
)

type MetricInfo struct {
	MetricName        string
	MetricDescription string
	MetricType        MetricTypes
	Query             string
}

var POOL_DB_METRICS []MetricInfo = []MetricInfo{
	{
		MetricName:        "zkevm_pool_size",
		MetricDescription: "The total number of entries in the pool.",
		MetricType:        GAUGE,
		Query:             "SELECT COUNT(*) cnt FROM pool.transaction;",
	},
	{
		MetricName:        "zkevm_txn_pool_pending",
		MetricDescription: "The current number of currently pending transactions in the pool.",
		MetricType:        GAUGE,
		Query:             "SELECT COUNT(*) cnt FROM pool.transaction WHERE status = 'pending';",
	},
	{
		MetricName:        "zkevm_pool_gas_price",
		MetricDescription: "The latest gas price from pool.gas_price.",
		MetricType:        GAUGE,
		Query:             "SELECT price FROM pool.gas_price ORDER BY item_id DESC LIMIT 1;",
	},
	{
		MetricName:        "zkevm_pool_gas_used",
		MetricDescription: "The mean gas used for pending transactions.",
		MetricType:        GAUGE,
		Query:             "SELECT AVG(cumulative_gas_used) AS mean_gas_used FROM pool.transaction WHERE status = 'pending';",
	},
	{
		MetricName:        "zkevm_txn_pool_wip",
		MetricDescription: "The current number of wip transactions in the pool.",
		MetricType:        GAUGE,
		Query:             "SELECT COUNT(*) cnt FROM pool.transaction WHERE status = 'pending' AND is_wip;",
	},
	{
		MetricName:        "zkevm_txn_pool_addresses",
		MetricDescription: "The current number of unique addresses that are pending in the transaction pool.",
		MetricType:        GAUGE,
		Query:             "SELECT COUNT(DISTINCT from_address) cnt FROM pool.transaction WHERE status = 'pending';",
	},
	{
		MetricName:        "zkevm_txn_pool_pending_claims",
		MetricDescription: "The current number of pending claims in the transaction pool.",
		MetricType:        GAUGE,
		Query:             "SELECT COUNT(*) cnt FROM pool.transaction WHERE status = 'pending' AND is_claims = true;",
	},
}

var STATE_DB_METRICS []MetricInfo = []MetricInfo{
	{
		MetricName:        "zkevm_block_number_gauge",
		MetricDescription: "The current block number.",
		MetricType:        GAUGE,
		Query:             "SELECT MAX(block_num) AS max_block_num FROM state.block;",
	},
	{
		MetricName:        "zkevm_l2block_number_gauge",
		MetricDescription: "The current l2block number.",
		MetricType:        GAUGE,
		Query:             "SELECT MAX(block_num) AS max_block_num FROM state.l2block;",
	},
	{
		MetricName:        "zkevm_batch_number_gauge",
		MetricDescription: "The current batch number.",
		MetricType:        GAUGE,
		Query:             "SELECT MAX(batch_num) AS max_batch_num FROM state.batch;",
	},
	{
		MetricName:        "zkevm_virtual_batch_number_gauge",
		MetricDescription: "The current virtual batch number.",
		MetricType:        GAUGE,
		Query:             "SELECT MAX(batch_num) AS max_virtual_batch_num FROM state.virtual_batch;",
	},
	{
		MetricName:        "zkevm_verified_batch_number_gauge",
		MetricDescription: "The current verified batch number.",
		MetricType:        GAUGE,
		Query:             "SELECT MAX(batch_num) AS max_verified_batch_num FROM state.verified_batch;",
	},
	{
		MetricName:        "zkevm_block_number",
		MetricDescription: "The max block number.",
		MetricType:        COUNTER,
		Query:             "SELECT MAX(block_num) AS max_block_num FROM state.block;",
	},
	{
		MetricName:        "zkevm_l2block_number",
		MetricDescription: "The max l2block number.",
		MetricType:        COUNTER,
		Query:             "SELECT MAX(block_num) AS max_block_num FROM state.l2block;",
	},
	{
		MetricName:        "zkevm_batch_number",
		MetricDescription: "The max batch number.",
		MetricType:        COUNTER,
		Query:             "SELECT MAX(batch_num) AS max_batch_num FROM state.batch;",
	},
	{
		MetricName:        "zkevm_virtual_batch_number",
		MetricDescription: "The max virtual batch number.",
		MetricType:        COUNTER,
		Query:             "SELECT MAX(batch_num) AS max_virtual_batch_num FROM state.virtual_batch;",
	},
	{
		MetricName:        "zkevm_verified_batch_number",
		MetricDescription: "The max verified batch number.",
		MetricType:        COUNTER,
		Query:             "SELECT MAX(batch_num) AS max_verified_batch_num FROM state.verified_batch;",
	},
	{
		MetricName:        "zkevm_state_proof_size",
		MetricDescription: "The number of rows in the state.proof table.",
		MetricType:        COUNTER,
		Query:             "SELECT COUNT(*) cnt FROM state.proof;",
	},
	{
		MetricName:        "zkevm_state_transaction_size",
		MetricDescription: "The number of rows in the state.transaction table.",
		MetricType:        COUNTER,
		Query:             "SELECT COUNT(*) cnt FROM state.transaction;",
	},
	{
		MetricName:        "zkevm_state_trusted_reorg_size",
		MetricDescription: "The number of rows in the state.trusted_reorg table.",
		MetricType:        COUNTER,
		Query:             "SELECT COUNT(*) cnt FROM state.trusted_reorg;",
	},
}

var PROVER_DB_METRICS []MetricInfo = []MetricInfo{
	{
		MetricName:        "zkevm_prover_nodes_size",
		MetricDescription: "The number of rows in the nodes table.",
		MetricType:        COUNTER,
		Query:             "SELECT COUNT(*) cnt FROM state.nodes;",
	},
	{
		MetricName:        "zkevm_state_program_size",
		MetricDescription: "The number of rows in the state.program table.",
		MetricType:        COUNTER,
		Query:             "SELECT COUNT(*) cnt FROM state.program;",
	},
}

var BRIDGE_DB_METRICS []MetricInfo = []MetricInfo{
	{
		MetricName:        "zkevm_sync_deposit_size",
		MetricDescription: "The number of rows in the sync deposit table.",
		MetricType:        COUNTER,
		Query:             "SELECT COUNT(*) cnt FROM sync.deposit;",
	},
	{
		MetricName:        "zkevm_sync_claim_size",
		MetricDescription: "The number of rows in the sync claims table.",
		MetricType:        COUNTER,
		Query:             "SELECT COUNT(*) cnt FROM sync.claim;",
	},
}

type BaseMetricInterface struct {
	gauge   prometheus.Gauge
	counter prometheus.Counter
	currVal float64
}

func (b *BaseMetricInterface) updateCurrVal(v float64) {
	b.currVal = v
}

var metricMap = make(map[string]*BaseMetricInterface)

func InitMetricInfos(reg *prometheus.Registry) {
	CreateMetricInfos(POOL_DB_METRICS, reg)
	CreateMetricInfos(STATE_DB_METRICS, reg)
	CreateMetricInfos(PROVER_DB_METRICS, reg)
	CreateMetricInfos(BRIDGE_DB_METRICS, reg)
}

func CreateMetricInfos(dbMetrics []MetricInfo, reg *prometheus.Registry) {
	for _, currMetric := range dbMetrics {
		var createdMetric *BaseMetricInterface

		if currMetric.MetricType == GAUGE {
			createdMetric = createPrometheusGauge(currMetric.MetricName, currMetric.MetricDescription)
			reg.MustRegister(createdMetric.gauge)
		} else if currMetric.MetricType == COUNTER {
			createdMetric = createPrometheusCounter(currMetric.MetricName, currMetric.MetricDescription)
			reg.MustRegister(createdMetric.counter)
		}

		metricMap[currMetric.MetricName] = createdMetric
	}
}

func main() {
	setLogLevel()
	reg := prometheus.NewRegistry()
	InitMetricInfos(reg)

	db, err := openDBConnection("zkevm")
	if err != nil {
		log.Error().Err(err).Msg("Unable to connect to zkevm db")
		os.Exit(1)
	}
	err = db.Close()
	if err != nil {
		log.Error().Err(err).Msg("Unexpected behavior while closing db connection")
		os.Exit(1)
	}

	addr := os.Getenv("ZKEVM_DBMON_HTTP_ADDR")

	http.HandleFunc("/metrics", func(w http.ResponseWriter, r *http.Request) {
		getAllMetricsValues()
		promhttp.HandlerFor(reg, promhttp.HandlerOpts{Registry: reg}).ServeHTTP(w, r)
	})

	http.ListenAndServe(addr, nil)
}

func getAllMetricsValues() {
	err := getDBMetricValues(POOL_DB, POOL_DB_METRICS)
	if err != nil {
		log.Error().Err(err).Msgf("Unable to generate %s metrics", POOL_DB)
	}
	err = getDBMetricValues(STATE_DB, STATE_DB_METRICS)
	if err != nil {
		log.Error().Err(err).Msgf("Unable to generate %s metrics", STATE_DB)
	}
	err = getDBMetricValues(PROVER_DB, PROVER_DB_METRICS)
	if err != nil {
		log.Error().Err(err).Msgf("Unable to generate %s metrics", PROVER_DB)
	}
	err = getDBMetricValues(BRIDGE_DB, BRIDGE_DB_METRICS)
	if err != nil {
		log.Error().Err(err).Msgf("Unable to generate %s metrics", BRIDGE_DB)
	}
}

func runDBMetricQueries(
	dbHandle *sql.DB,
	dbMetrics []MetricInfo,
) error {
	for _, currMetric := range dbMetrics {
		val, err := scanForInt(dbHandle, currMetric.Query)
		if err != nil {
			return err
		}

		if currMetric.MetricType == GAUGE {
			metricMap[currMetric.MetricName].gauge.Set(float64(val))
		} else if currMetric.MetricType == COUNTER {
			prevVal := metricMap[currMetric.MetricName].currVal
			addVal := float64(val) - prevVal
			// This shouldn't ever happen but counter.Add() panics if it's a negative
			if addVal < 0 {
				log.Error().Err(err).Msg("Can't add negative values in Counter")
				continue
			}
			metricMap[currMetric.MetricName].counter.Add(addVal)
		}

		metricMap[currMetric.MetricName].updateCurrVal(float64(val))
	}

	return nil
}

func getDBMetricValues(dbName string, metricInfos []MetricInfo) error {
	dbConn, err := openDBConnection(dbName)
	if err != nil {
		log.Error().Err(err).Msg("Unable to open connection to " + dbName)
		return err
	}
	defer dbConn.Close()

	err = runDBMetricQueries(dbConn, metricInfos)
	if err != nil {
		log.Error().Err(err).Msg("Unable to create metrics")
		return err
	}

	return nil
}

func scanForInt(dbHandle *sql.DB, query string) (int64, error) {
	rows, err := getRows(dbHandle, query)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	var res sql.NullInt64
	err = rows.Scan(&res)
	if err != nil {
		log.Error().Err(err).Msg("Unable to read value")
		return 0, err
	}

	if !res.Valid {
		return 0, nil
	}

	return res.Int64, nil
}

func getRows(dbHandle *sql.DB, query string) (*sql.Rows, error) {
	rows, err := dbHandle.Query(query)
	if err != nil {
		log.Error().Err(err).Msg("Error fetching rows")
		return nil, err
	}
	rows.Next()
	err = rows.Err()
	if err != nil {
		log.Error().Err(err).Msg("Unable to iterate row")
		return nil, err
	}
	return rows, nil
}

func createPrometheusGauge(name string, help string) *BaseMetricInterface {
	newGauge := prometheus.NewGauge(prometheus.GaugeOpts{
		Name: name,
		Help: help,
	})

	return &BaseMetricInterface{gauge: newGauge}
}

func createPrometheusCounter(name string, help string) *BaseMetricInterface {
	name = fmt.Sprintf("%s_total", name)
	newCounter := prometheus.NewCounter(prometheus.CounterOpts{
		Name: name,
		Help: help,
	})

	return &BaseMetricInterface{counter: newCounter}
}

func openDBConnection(dbName string) (*sql.DB, error) {
	user := os.Getenv("ZKEVM_DBMON_DATABASE_USER")
	pass := os.Getenv("ZKEVM_DBMON_DATABASE_PASS")
	host := os.Getenv("ZKEVM_DBMON_DATABASE_HOST")
	connString := fmt.Sprintf("postgres://%s:%s@%s/%s", user, pass, host, dbName)
	db, err := sql.Open("postgres", connString)
	if err != nil {
		log.Error().Err(err).Msg("Unable to connect to database")
	}
	err = db.Ping()
	if err != nil {
		log.Error().Err(err).Msg("unable to ping db")
	}

	return db, err
}

func setLogLevel() {
	verb := os.Getenv("ZKEVM_DBMON_VERBOSITY")
	if verb == "panic" {
		zerolog.SetGlobalLevel(zerolog.PanicLevel)
	} else if verb == "fatal" {
		zerolog.SetGlobalLevel(zerolog.FatalLevel)
	} else if verb == "error" {
		zerolog.SetGlobalLevel(zerolog.ErrorLevel)
	} else if verb == "warn" {
		zerolog.SetGlobalLevel(zerolog.WarnLevel)
	} else if verb == "info" {
		zerolog.SetGlobalLevel(zerolog.InfoLevel)
	} else if verb == "debug" {
		zerolog.SetGlobalLevel(zerolog.DebugLevel)
	} else if verb == "trace" {
		zerolog.SetGlobalLevel(zerolog.TraceLevel)
	}

	pretty := os.Getenv("ZKEVM_DBMON_PRETTY")
	if pretty == "true" {
		log.Logger = log.Output(zerolog.ConsoleWriter{Out: os.Stderr})
		log.Debug().Msg("Starting logger in console mode")
	} else {
		log.Debug().Msg("Starting logger in JSON mode")
	}
}
