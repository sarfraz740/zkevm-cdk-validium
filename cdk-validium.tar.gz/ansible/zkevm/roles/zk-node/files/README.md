# DBMon

DBMon is a service to generate prometheus metrics for zkEVM.
The service queries a variety of application level values from the databases to enable monitors,
that are not generally accessible from JSON-RPCs and the likes, to detect meaningful events.

## zkEVM DB Documentation

For a full reference on the available zkEVM schemas, please refer [here](docs/README.md).

## Prerequisites

- [Go](https://go.dev/)
- [tbls](https://github.com/k1LoW/tbls)

## 1. Establish Connection

First, open a tunnel to the database:
`ssh -L 5432:zkevm-db:5432 ubuntu@i-0b8b23876937b7d46`

or via SSM on AWS:
```
aws ssm start-session \
    --target <instance ID> \
    --document-name AWS-StartPortForwardingSessionToRemoteHost \
    --parameters '{"host":["zkevm-db"],"portNumber":["5432"], "localPortNumber":["5432"]}'
```

## 2. Running Service
Next setup environment variables and run the application. Sample env:
```
set -a
ZKEVM_DBMON_DATABASE_USER=<DB_USER>
ZKEVM_DBMON_DATABASE_PASS=<DB_PASS>
ZKEVM_DBMON_DATABASE_HOST=<DB_HOST>
ZKEVM_DBMON_HTTP_ADDR=<dbmon backend port>
ZKEVM_DBMON_VERBOSITY=trace
set +a
```

then run service:
```
$ go run main.go
```

From there, you should be able to test retrieval of the prometheus metrics:
```
curl localhost:<dbmon backend port>/metrics
```

## Generating documentation
Setup environment variables as follows (typically the same as above but with `$PGPASSWORD`):
```
set -a
ZKEVM_DBMON_DATABASE_USER=<DB_USER>
ZKEVM_DBMON_DATABASE_PASS=<DB_PASS>
ZKEVM_DBMON_DATABASE_HOST=<DB_HOST>
PGPASSWORD=$ZKEVM_DBMON_DATABASE_PASS
set +a
```

Then run script to generate docs:
```
cd docs
./gen-doc.sh
```
