#!/bin/bash

ZKEVM_DBMON_DATABASE_USER=master ZKEVM_DBMON_DATABASE_PASS={{ zkevm_db_password }} ZKEVM_DBMON_DATABASE_HOST={{ datadog_postgres_integration_host }}:5432 ZKEVM_DBMON_HTTP_ADDR=:{{ dbmon_openmetrics_port }} ZKEVM_DBMON_VERBOSITY=trace dbmon
