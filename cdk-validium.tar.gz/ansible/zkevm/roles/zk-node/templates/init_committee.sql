CREATE DATABASE committee_db;
\connect committee_db;

CREATE SCHEMA committee;

CREATE USER committee_user with password '{{ zkevm_committee_db_password }}';

-- Grant rootuser perms (GCP root user isn't the same as superuser)
GRANT ALL ON ALL TABLES IN SCHEMA committee TO {{ zkevm_database_root_user }};
GRANT committee_user TO {{ zkevm_database_root_user }};

GRANT CONNECT ON DATABASE committee_db TO committee_user;
GRANT USAGE ON SCHEMA committee TO committee_user;

GRANT ALL ON ALL TABLES IN SCHEMA committee TO committee_user;

GRANT CREATE ON DATABASE committee_db TO committee_user;

DROP SCHEMA committee;

-- DataDog
CREATE SCHEMA datadog;
GRANT USAGE ON SCHEMA datadog TO datadog;
GRANT USAGE ON SCHEMA public TO datadog;
GRANT pg_monitor TO datadog;
CREATE EXTENSION IF NOT EXISTS pg_stat_statements schema public;

CREATE OR REPLACE FUNCTION datadog.explain_statement(
   l_query TEXT,
   OUT explain JSON
)
RETURNS SETOF JSON AS
$$
DECLARE
curs REFCURSOR;
plan JSON;

BEGIN
   OPEN curs FOR EXECUTE pg_catalog.concat('EXPLAIN (FORMAT JSON) ', l_query);
   FETCH curs INTO plan;
   CLOSE curs;
   RETURN QUERY SELECT plan;
END;
$$
LANGUAGE 'plpgsql'
RETURNS NULL ON NULL INPUT
SECURITY DEFINER;
