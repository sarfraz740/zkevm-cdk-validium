CREATE DATABASE pool_db;
\connect pool_db;

CREATE SCHEMA pool;

CREATE USER pool_user with password '{{ zkevm_pool_db_password }}';

-- Grant rootuser perms (GCP root user isn't the same as superuser)
GRANT ALL ON ALL TABLES IN SCHEMA pool TO {{ zkevm_database_root_user }};
GRANT pool_user TO {{ zkevm_database_root_user }};

GRANT CONNECT ON DATABASE pool_db TO pool_user;
GRANT USAGE ON SCHEMA pool TO pool_user;

GRANT ALL ON ALL TABLES IN SCHEMA pool TO pool_user;

GRANT CREATE ON DATABASE pool_db TO pool_user;

DROP SCHEMA pool;

-- DataDog
CREATE SCHEMA datadog;
GRANT USAGE ON SCHEMA datadog TO datadog;
GRANT USAGE ON SCHEMA public TO datadog;
GRANT pg_monitor TO datadog;
CREATE EXTENSION IF NOT EXISTS pg_stat_statements schema public;

CREATE OR REPLACE FUNCTION datadog.explain_statement(
   l_query TEXT,
   OUT explain JSON
)
RETURNS SETOF JSON AS
$$
DECLARE
curs REFCURSOR;
plan JSON;

BEGIN
   OPEN curs FOR EXECUTE pg_catalog.concat('EXPLAIN (FORMAT JSON) ', l_query);
   FETCH curs INTO plan;
   CLOSE curs;
   RETURN QUERY SELECT plan;
END;
$$
LANGUAGE 'plpgsql'
RETURNS NULL ON NULL INPUT
SECURITY DEFINER;
