-- Checking transactions in pool
select
*

from
pool.transaction

order by nonce desc

limit 1000;


select
*

from
pool.transaction

where
nonce > 6000

order by nonce asc

limit 200;


select
count(*),
status

from
pool.transaction

group by status;

-- Query to delete some pending / failed transactions while testing
delete from pool.transaction
where status in ('pending')
and nonce >= 93705 
-- and from_address = '0x85dA99c8a7C2C95964c8EfD687E95E632Fc533D6'


-- Some notes from
-- Each transaction is mined in a block. Tx to Block is 1:1
-- Each Bach can have many blocks. Block to Batch is 1:*
-- In the State there is a progression of finality / confirmation
---- Trusted
---- Virtual (means we've sent to the L1)
---- Verified (means the zkp has been verified on the L1)


select count(*), batch_num from state.l2block group by batch_num order by batch_num;

select * from state.transaction order by l2_block_num desc limit 100;
select * from state.batch order by batch_num desc limit 100;
SELECT * FROM state.l2block order by block_num desc limit 100;
SELECT * from state.sequences order by from_batch_num desc limit 100;
SELECT * FROM state.proof order by batch_num;
select * from state.virtual_batch order by batch_num desc limit 100;
select * from state.verified_batch order by batch_num desc limit 100;


select max(v.batch_num) last_virtual from state.virtual_batch v;
select max(p.batch_num_final) last_proved from state.proof p where p.proof_id is not null and p.batch_num > (select max(v.batch_num) from state.verified_batch v);